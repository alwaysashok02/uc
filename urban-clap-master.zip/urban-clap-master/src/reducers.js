import { combineReducers } from 'redux';
import {pageReducer} from './reducers/pageReducer.js'


const rootReducer=combineReducers({
      pageReducer
   })

export default rootReducer